<div class="alert alert-danger alert-dismissable text-center">
    <i class="fa fa-warning"></i>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <b>Inscrições Encerradas!</b>
</div>