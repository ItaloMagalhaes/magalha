<form name="form" id="form" action="sistema.php?acao=congressista/matricularCongressistaEditar" method="post">        
 
	<?php echo $info['listagem'];?>
	<div class="form-group">
		<div class="col-sm-offset-2 col-sm-10 ">
			<button class="btn btn-grey1 pull-right" id="salvar" name="salvar" type="submit">Salvar</button> 
		</div>
	</div>

</form>