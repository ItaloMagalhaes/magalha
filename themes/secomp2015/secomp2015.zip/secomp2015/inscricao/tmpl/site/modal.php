    <div class="modal fade" id="ModalErro" tabindex="-1" data-backdrop="static" data-keyboard="false" role="dialog" aria-labelledby="modal-header-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header alert alert-danger" id="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Fechar</span></button>
                    <div class="modal-title"></div>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer"></div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="ModalSucesso" tabindex="-1" data-backdrop="static" data-keyboard="false" role="dialog" aria-labelledby="modal-header-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header alert alert-success" id="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Fechar</span></button>
                    <div class="modal-title"></div>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer"></div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="myModal" tabindex="-1" data-backdrop="static" data-keyboard="false" role="dialog" aria-labelledby="modal-header-1" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header alert alert-warning" id="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Fechar</span></button>
                    <div class="modal-title"></div>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer"><button type="button" class="btn btn-grey1" id="sim" data-dismiss="modal"><span class="glyphicon glyphicon-ok"></span></button></div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="myModal1" tabindex="-1" data-backdrop="static" data-keyboard="false" role="dialog" aria-labelledby="modal-header-1" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header alert alert-warning" id="modal-header2">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                    <div class="modal-title"></div>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer"></div>
            </div>
        </div>
    </div>