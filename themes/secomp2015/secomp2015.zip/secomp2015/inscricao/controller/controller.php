<?php

/**
 * Controller
 * 
 * Camada base de controle
 * 
 *
 */

class Controller {
    
}
?>
