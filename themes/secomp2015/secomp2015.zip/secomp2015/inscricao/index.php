<?php
	
	header("Location:sistema.php?acao=site/telaInicial");

?>
<--!mexido>